V2X-Seq-SPD 速度与曲率预测数据生成脚本解析

该脚本用于处理车辆侧视角图像及其对应定位信息，从中构造用于速度-曲率预测的训练样本，并输出为 all_samples.json 文件。

输出文件结构

输出为一个包含多个样本的列表，每个样本格式如下：

{
  "query": "These are frames from a video taken...",
  "response": [[v1, c1], [v2, c2], ..., [v10, c10]],
  "history_images": ["img1.jpg", ..., "img10.jpg"],
  "future_images": ["img11.jpg", ..., "img20.jpg"],
  "intersection": "intersection_name",
  "sequence_id": "0001"
}

字段说明与计算方式

1. query

说明：用于引导模型预测的 prompt。

构建方式：模板形式如下：

These are frames from a video taken by a camera mounted in the front of a car. Each image is sampled at a 0.5 second interval.
The 4.5-second historical velocities and curvatures of the ego car are [s1, c1], [s2, c2], ..., [s10, c10].
Predict the 4.5-second future velocities and curvatures corresponding to the next 10 frames.

数据来源：

velocity 与 curvature 均通过对车辆在世界坐标下的位置（novatel）进行时间差与空间差的计算得到。

前 10 帧的计算值被拼入 query 字符串中，形成自然语言输入（历史轨迹信息）。

2. response

说明：未来 10 帧的速度与曲率列表。

来源：与 query 相同方式计算的后 10 帧速度与曲率值。

格式：数值精度保留三位（速度）与五位（曲率），例如：

[[5.123, 0.00234], [4.980, 0.00192], ..., [6.002, 0.00000]]

3. history_images

说明：前 10 帧图像路径。

来源：每隔 5 帧采样图像路径中前 10 张。

4. future_images

说明：后 10 帧图像路径。

来源：采样路径中后 10 张图像。

5. intersection

说明：样本对应场景的十字路口 ID。

来源：由基础设施侧的 data_info.json 提供，通过图像路径映射得到。

6. sequence_id

说明：图像序列 ID，表示这些图像属于同一个视频序列。

校验：确保该样本内所有帧的 sequence_id 一致。

7. image_timestamp

说明：图像帧拍摄时间戳，单位为微秒（μs），用于速度计算。

来源：每帧对应的 data_info.json，位于如下路径：

/V2X-Seq-SPD/vehicle-side/{sequence_folder}/data_info.json

每个 data_info.json 文件包含该序列下所有图像帧的路径、时间戳、标注路径等元信息。

中间值计算方式

✅ speed（单位：m/s）

speed = distance / dt

distance：相邻两帧的位置欧氏距离（世界坐标）

dt：时间差（由 image_timestamp 相减后除以 1e6）

✅ curvature（无单位）

curvature = 4 * area / (a * b * c)

由三个点构成三角形面积 area 和三边长度 a, b, c 计算

使用叉积近似公式求面积

三点共线时结果为 0

切分执行流程

载入基础设施侧图像-元数据映射（infra_map）

遍历车辆侧所有 data_info.json 序列

每 5 帧采样一次，构造长度为 20 的帧子序列

对每帧获取世界坐标位置（由 novatel_to_world JSON）

计算速度和曲率

构造 query、response、图像路径、元数据

保存所有结果为 all_samples.json

训练集 / 测试集划分逻辑

划分策略：以 intersection 为单位进行划分，每个交叉口随机抽取 20% 的样本为测试集，80% 为训练集。采用固定种子 random.seed(42) 以保证实验可复现。

步骤说明：

载入 all_samples.json 数据。

按 intersection 字段分组。

每个分组中随机打乱样本顺序后划分为 train/test。

仅保留必要字段（query, response, future_images）输出为 train_data.json 和 test_data.json。